import pandas as pd

# Load dataset
df = pd.read_csv("master_security_dataset.csv")

# Check required columns
required_cols = ["Log", "Attack Type", "Source"]
missing = [col for col in required_cols if col not in df.columns]

if missing:
    raise ValueError(f"Missing columns: {missing}")

# Extract unique sources
unique_sources = df["Source"].dropna().unique()

# Print results
print("Unique Sources:\n")
for src in sorted(unique_sources):
    print(src)

print(f"\nTotal unique sources: {len(unique_sources)}")